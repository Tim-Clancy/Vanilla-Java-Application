import java.util.HashMap;
import java.util.Set;

public class Test003 {
    public static void main(String args[]) {

        regNo reg = new regNo();
        Keeper keeper = new Keeper();
        Address address = new Address();
        DVLA d1 = new DVLA();

        address.setStreet("201 Astley Street");
        address.setTown("Tyldesley");
        address.setPostcode("M297AG");

        reg.setRegNo("SA52OUG");
        d1.RegNum.put(1, reg.getRegNo());
        reg.setRegNo("YS57WDF");
        d1.RegNum.put(2, reg.getRegNo());
        reg.setRegNo("WD55YOU");
        d1.RegNum.put(3, reg.getRegNo());
        reg.setRegNo("KL04JGU");
        d1.RegNum.put(4, reg.getRegNo());



        keeper.setForename("Tim");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(1,keeper.toString());

        keeper.setForename("Matt");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(2,keeper.toString());

        keeper.setForename("Pat");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(3,keeper.toString());

        keeper.setForename("David");
        keeper.setSurname("Womersley");
        keeper.setAddress(address.toString());
        d1.Keeper.put(4, keeper.toString());

        Set<Integer> key = d1.RegNum.keySet();
        Set<Integer> value = d1.Keeper.keySet();

        for(Integer i: key) {
            Integer x = i;
            for(Integer a : value) {
                Integer y = a;
                if(x == y) {
                    d1.KeepNreg.put(d1.RegNum.get(x),d1.Keeper.get(y));
                }
            }
        }

        d1.showAllKeepers(d1.KeepNreg);


    }
}
