public class Test001 {
    public static void main(String args[]){

        regNo reg = new regNo();
        Car car = new Car();
        DVLA d1 = new DVLA();



        car.setMake("Maserati");
        car.setModel("Grancabrio");
        car.setColour("Verde Opale");
        d1.Car.put(1, car.toString());

        reg.setRegNo("SA52OUG");
        d1.RegNum.put(1, reg.getRegNo());


        car.setMake("Ferrari");
        car.setModel("Testarossa");
        car.setColour("Rosso Corsa");
        d1.Car.put(2, car.toString());

        reg.setRegNo("KL04JGU");
        d1.RegNum.put(2, reg.getRegNo());


        car.setMake("Lamborghini");
        car.setModel("Miura");
        car.setColour("Giallo Sole");
        d1.Car.put(3, car.toString());

        reg.setRegNo("YS57WDF");
        d1.RegNum.put(3, reg.getRegNo());






        d1.printKeys(d1.Car, d1.RegNum);




    }
}
