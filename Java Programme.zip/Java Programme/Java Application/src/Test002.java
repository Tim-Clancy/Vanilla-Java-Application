import java.util.Map;

public class Test002 {
    public static void main(String args[]) {

        regNo reg = new regNo();
        Car car = new Car();
        DVLA d1 = new DVLA();


        car.setMake("Maserati");
        car.setModel("Grancabrio");
        car.setColour("Verde Opale");
        reg.setRegNo("SA52OUG");

        d1.Car.put(3, car.toString());
        d1.RegNum.put(1, reg.getRegNo());


        car.setMake("Ferrari");
        car.setModel("Testarossa");
        car.setColour("Rosso Corsa");
        reg.setRegNo("KL04JGU");

        d1.Car.put(1, car.toString());
        d1.RegNum.put(3, reg.getRegNo());


        car.setMake("Lamborghini");
        car.setModel("Miura");
        car.setColour("Giallo Sole");
        reg.setRegNo("YS57WDF");

        d1.Car.put(2, car.toString());
        d1.RegNum.put(2, reg.getRegNo());


        for (Map.Entry<Integer, String> entry : d1.getTreeMap(d1.RegNum).entrySet()) {
            System.out.println("Key: " + entry.getKey() + ". Value: " + entry.getValue());
        }

    }
}
