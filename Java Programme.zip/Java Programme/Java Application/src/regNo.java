import java.util.Objects;

public class regNo implements Comparable{

    private String regNo;


    public regNo() {
        regNo = "KL04JGU";
    }
    public regNo(String regNo) {
        this.regNo = regNo;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof regNo)) return false;
        regNo regNo1 = (regNo) o;
        return Objects.equals(regNo, regNo1.regNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(regNo);
    }


    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
