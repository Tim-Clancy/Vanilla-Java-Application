import java.io.*;
import java.time.Month;
import java.util.ArrayList;

public class Test005 {

    public static void main (String[]args){

        Keeper keeper = new Keeper();
        Address address = new Address();
        DVLA d1 = new DVLA();

        address.setStreet("201 Astley Street");
        address.setTown("Tyldesley");
        address.setPostcode("M297AG");

        keeper.setForename("Tim");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(1, keeper.toString());


        keeper.setForename("Matt");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(2, keeper.toString());


        keeper.setForename("Pat");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(3, keeper.toString());


        keeper.setForename("David");
        keeper.setSurname("Womersley");
        keeper.setAddress(address.toString());
        d1.Keeper.put(4, keeper.toString());

        keeper.setForename("Susan");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(5, keeper.toString());

        keeper.setForename("John");
        keeper.setSurname("Smith");
        keeper.setAddress(address.toString());
        d1.Keeper.put(6, keeper.toString());

        keeper.setForename("John");
        keeper.setSurname("Doe");
        keeper.setAddress(address.toString());
        d1.Keeper.put(7, keeper.toString());

        keeper.setForename("Mark");
        keeper.setSurname("Smith");
        keeper.setAddress(address.toString());
        d1.Keeper.put(8, keeper.toString());

        keeper.setForename("Sally");
        keeper.setSurname("Smith");
        keeper.setAddress(address.toString());
        d1.Keeper.put(9, keeper.toString());

        keeper.setForename("John");
        keeper.setSurname("Mark");
        keeper.setAddress(address.toString());
        d1.Keeper.put(10, keeper.toString());

        keeper.setForename("Michael");
        keeper.setSurname("Patrick-Paisley");
        keeper.setAddress(address.toString());
        d1.Keeper.put(11, keeper.toString());

        keeper.setForename("Paul");
        keeper.setSurname("Dale");
        keeper.setAddress(address.toString());
        d1.Keeper.put(12, keeper.toString());


        Integer count1 = 1;
        for (Month i : Month.values()) {
            d1.reTax.put(String.valueOf(i), d1.Keeper.get(count1));
            count1++;
        }

        d1.showAllKeepers1(d1.reTax);
        System.out.println("\n\n\n\n ######## SERIALIZATION DEMO ######## \n");

        try{
            FileOutputStream fileOut = new FileOutputStream("taxREMINDER.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeUTF(String.valueOf(d1.taxRemind));
            out.close();
            fileOut.close();
            System.out.println("Serialized Data For Tax Reminder Letters Saved in taxREMINDER.ser");
        } catch (IOException i){
            i.printStackTrace();
        }




        try {
            FileOutputStream fileOut = new FileOutputStream("taxOVERDUE.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeUTF(d1.taxCancel.toString());
            out.close();
            fileOut.close();
            System.out.println("Serialized Data For Tax Overdue Letters Saved in taxOVERDUE.ser");
        } catch (IOException i) {
            i.printStackTrace();
        }



        String a = null;
        String b = null;

        try {
            FileInputStream fileIn = new FileInputStream("taxOVERDUE.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            a = (String) in.readUTF();
            in.close();
            fileIn.close();
        } catch (IOException i) {
            i.printStackTrace();
            return;
        }



        try {
            FileInputStream fileIn = new FileInputStream("taxREMINDER.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            b = (String) in.readUTF();
            in.close();
            fileIn.close();
        } catch (IOException i) {
            i.printStackTrace();
            return;
        }
        System.out.println(a);
        System.out.println(b);



    }

}
