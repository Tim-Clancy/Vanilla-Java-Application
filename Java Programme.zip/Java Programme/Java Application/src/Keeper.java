public class Keeper {

    private String forename;
    private String surname;
    private String address;

    public Keeper() {
        forename = "Blue";
        surname = "Ford";
    }

    public Keeper(String forename, String address, String surname) {
        this.forename = forename;
        this.surname = surname;
    }

    public String getForename() {
        return forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }


    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        var format = forename +" "+ surname +" \n" + address + ".";
        return format;
    }
}
