import java.time.LocalDate;
import java.time.Month;
import java.util.*;

public class DVLA{
    HashMap<Integer, String> RegNum = new HashMap<Integer, String>();
    HashMap<Integer, String> Car = new HashMap<Integer, String>();
    HashMap<Integer, String> Keeper = new HashMap<Integer, String>();

    HashMap<String, String> KeepNreg = new HashMap<String, String>();
    HashMap<String, String> reTax = new HashMap<String, String>();
    ArrayList<String> taxCancel = new ArrayList<String>();
    String taxRemind = "";

    private Month month;


    public Map<Integer, String> getTreeMap(Map<Integer, String> hashMap) {
        Map<Integer, String> treeMap = new TreeMap<>();
        treeMap.putAll(hashMap);

        return treeMap;
    }

    public void printKeys(HashMap a, HashMap b) {
        Set<Integer> key1 = a.keySet();
        for (Integer i : key1) {
            System.out.println(a.get(i) + "\nReg: " + b.get(i) + "\n");
        }
    }

    public void showAllKeepers(HashMap<String, String> a) {

        Set<String> key = a.keySet();

        for(String i: key) {
            System.out.println("Owner:\n" + a.get(i) + "\n" + "Reg: " + i + "\n\n");
        }

    }

    public void showAllKeepers1(HashMap<String, String> a) {

        Set<String> key = a.keySet();
        for(String i: key) {
            if (i == monthCheck1()){
                System.out.println("Owner:\n" + a.get(i) + "\n" + "Tax End Date: " + i + ".\nTax Ends This Month, Send Urgent Reminder.\n");
                taxRemind = a.get(i);
            } else if(monthCheck2(i) < 5){
                System.out.println("Owner:\n" + a.get(i) + "\n" + "Tax End Date: " + i + ".\nTax Expired " + (5-monthCheck2(i)) + " Month(s) ago, Send Cancellation Notice.\n");
                taxCancel.add(a.get(i));
            }  else if(monthCheck2(i) + 1 <= 7){
                System.out.println("Owner:\n" + a.get(i) + "\n" + "Tax End Date: " + i + ".\nTax Expires Next Month, Send Reminder.\n");
            } else {
                System.out.println("Owner:\n" + a.get(i) + "\n" + "Tax End Date: " + i + ".\nTax Valid.\n");
            }
        }

    }

    public String monthCheck1(){
        LocalDate date = LocalDate.now();
        Month month = date.getMonth();
        return String.valueOf(month);
    }

    public Integer monthCheck2(String a){

        Integer MonthNum = 0;
        switch(a) {
            case "JANUARY":
                MonthNum = 1;
                break;
            case "FEBRUARY":
                MonthNum = 2;
                break;
            case "MARCH":
                MonthNum = 3;
                break;
            case "APRIL":
                MonthNum = 4;
                break;
            case "MAY":
                MonthNum = 5;
                break;
            case "JUNE":
                MonthNum = 6;
                break;
            case "JULY":
                MonthNum = 7;
                break;
            case "AUGUST":
                MonthNum = 8;
                break;
            case "SEPTEMBER":
                MonthNum = 9;
                break;
            case "OCTOBER":
                MonthNum = 10;
                break;
            case "NOVEMBER":
                MonthNum = 11;
                break;
            case "DECEMBER":
                MonthNum = 12;
                break;
        }
        return MonthNum;
    }


    public void serialize(String a){

    }

}

