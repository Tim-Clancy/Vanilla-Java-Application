import java.time.Month;

public class Test004 {

    public static void main(String[] args){

        Keeper keeper = new Keeper();
        Address address = new Address();
        DVLA d1 = new DVLA();

        address.setStreet("201 Astley Street");
        address.setTown("Tyldesley");
        address.setPostcode("M297AG");

        keeper.setForename("Tim");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(1,keeper.toString());


        keeper.setForename("Matt");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(2,keeper.toString());


        keeper.setForename("Pat");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(3,keeper.toString());


        keeper.setForename("David");
        keeper.setSurname("Womersley");
        keeper.setAddress(address.toString());
        d1.Keeper.put(4, keeper.toString());

        keeper.setForename("Susan");
        keeper.setSurname("Clancy");
        keeper.setAddress(address.toString());
        d1.Keeper.put(5, keeper.toString());

        keeper.setForename("John");
        keeper.setSurname("Smith");
        keeper.setAddress(address.toString());
        d1.Keeper.put(6, keeper.toString());

        keeper.setForename("John");
        keeper.setSurname("Doe");
        keeper.setAddress(address.toString());
        d1.Keeper.put(7, keeper.toString());

        keeper.setForename("Mark");
        keeper.setSurname("Smith");
        keeper.setAddress(address.toString());
        d1.Keeper.put(8, keeper.toString());

        keeper.setForename("Sally");
        keeper.setSurname("Smith");
        keeper.setAddress(address.toString());
        d1.Keeper.put(9, keeper.toString());

        keeper.setForename("John");
        keeper.setSurname("Mark");
        keeper.setAddress(address.toString());
        d1.Keeper.put(10, keeper.toString());

        keeper.setForename("Michael");
        keeper.setSurname("Patrick-Paisley");
        keeper.setAddress(address.toString());
        d1.Keeper.put(11, keeper.toString());

        keeper.setForename("Paul");
        keeper.setSurname("Dale");
        keeper.setAddress(address.toString());
        d1.Keeper.put(12, keeper.toString());


        Integer count = 1;
        for(Month i : Month.values()) {
            d1.reTax.put(String.valueOf(i) ,d1.Keeper.get(count));
            count++;
        }

        d1.showAllKeepers1(d1.reTax);

        System.out.println(d1.taxRemind);
        for(String i : d1.taxCancel){
            System.out.println(i);
        }


    }
}
